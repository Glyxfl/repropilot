# ReproPilot analysis delivery

Run: d1e257160bf3 | Dataset: Pasilla knock-down | Kind: public

## Research question
使用 pasilla 公开数据，比较 treated vs untreated，校正测序类型；FDR < 0.05，|log2FC| >= 1，生成火山图、PCA 和可复现报告。

## Frozen method
- Design: `~ library_type + condition`
- Contrast: treated / untreated; positive log2FC = higher in treated.
- Pre-filter: counts >= 10 in at least 3 samples.
- PyDESeq2 negative-binomial model, Wald test, Benjamini-Hochberg correction.
- Significant: padj < 0.05 and |unshrunk log2FC| >= 1.0.
- Cook's filtering and independent filtering enabled. NA padj excluded from discoveries.

## Computed results
7 samples; 14599 input genes; 8148 retained;
8148 non-NA padj; 0 NA padj.
115 upregulated and 111 downregulated genes under these thresholds.

## Interpretation boundaries
These are statistical associations in the supplied experiment, not validated mechanisms.
Exploratory PCA uses log2(normalized counts + 1) on the 500 most variable retained genes, not VST.
No enrichment, pathway, causal or clinical conclusions were computed.
Sequencing library type is a known protocol covariate, not a claim that all batch effects are controlled.
Changing the formula or thresholds requires a new approved plan. No samples were automatically dropped.

## Provenance and reproduction
Source: https://bioconductor.org/packages/pasilla/ (GSE18508). Input hashes and package versions are in manifest.json.
Run `python reproduce.py` from this delivery directory after installing the project requirements.
Reproduction writes a separate replay/differential_expression.csv; exact floating-point equality can vary across BLAS/platform versions.
